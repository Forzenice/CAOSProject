﻿namespace Main_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea17 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea18 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea19 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea20 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnVM = new System.Windows.Forms.Button();
            this.btnMMBF = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnNPP = new System.Windows.Forms.Button();
            this.btnFCFS = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelCPUFCFS = new System.Windows.Forms.Panel();
            this.FCFSgantt = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dgvCYFCFS = new System.Windows.Forms.DataGridView();
            this.btnCYreturn = new System.Windows.Forms.Button();
            this.lblCYCPUU = new System.Windows.Forms.Label();
            this.lblCYRT = new System.Windows.Forms.Label();
            this.lblCYWT = new System.Windows.Forms.Label();
            this.lblCYTAT = new System.Windows.Forms.Label();
            this.btnCYStart = new System.Windows.Forms.Button();
            this.btnCYClr = new System.Windows.Forms.Button();
            this.btnCYRemove = new System.Windows.Forms.Button();
            this.btnCYAdd = new System.Windows.Forms.Button();
            this.txtCYAT = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCYBT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCYPP = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panelNPP = new System.Windows.Forms.Panel();
            this.chtPriority = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblResult2 = new System.Windows.Forms.Label();
            this.txtSave = new System.Windows.Forms.TextBox();
            this.btnLocation = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Process = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ArrivalTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BurstTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.txtPriority = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtArrivalTime = new System.Windows.Forms.TextBox();
            this.txtBurstTime = new System.Windows.Forms.TextBox();
            this.txtProcess = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panelMainMemory = new System.Windows.Forms.Panel();
            this.MMMBlockchart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel4 = new System.Windows.Forms.Panel();
            this.returnMP = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.errorJY = new System.Windows.Forms.Label();
            this.GridViewMemJY2 = new System.Windows.Forms.DataGridView();
            this.processQueueJY1 = new System.Windows.Forms.DataGridView();
            this.unloadedBlk = new System.Windows.Forms.Label();
            this.extFrag = new System.Windows.Forms.Label();
            this.internFrag = new System.Windows.Forms.Label();
            this.startMM = new System.Windows.Forms.Button();
            this.processSizeTxtBox = new System.Windows.Forms.TextBox();
            this.orderNoTxtBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.addProcess = new System.Windows.Forms.Button();
            this.addMemBlock = new System.Windows.Forms.Button();
            this.newMemBlk = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.removeblk = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.MMDChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.processQueueJY2 = new System.Windows.Forms.DataGridView();
            this.label26 = new System.Windows.Forms.Label();
            this.panelVM = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.lblPageFault = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblProbability = new System.Windows.Forms.Label();
            this.csdataGridView1 = new System.Windows.Forms.DataGridView();
            this.Frame = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.databits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PageFault = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Occurence = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.METHOD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnFIFO = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtDatabits = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtFrame = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.btnBackVM = new System.Windows.Forms.Button();
            this.mainPanel.SuspendLayout();
            this.panelCPUFCFS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FCFSgantt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCYFCFS)).BeginInit();
            this.panelNPP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelMainMemory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MMMBlockchart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewMemJY2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.processQueueJY1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MMDChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.processQueueJY2)).BeginInit();
            this.panelVM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.csdataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // mainPanel
            // 
            this.mainPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mainPanel.Controls.Add(this.label1);
            this.mainPanel.Controls.Add(this.btnVM);
            this.mainPanel.Controls.Add(this.btnMMBF);
            this.mainPanel.Controls.Add(this.label5);
            this.mainPanel.Controls.Add(this.label4);
            this.mainPanel.Controls.Add(this.label3);
            this.mainPanel.Controls.Add(this.label2);
            this.mainPanel.Controls.Add(this.btnNPP);
            this.mainPanel.Controls.Add(this.btnFCFS);
            this.mainPanel.Controls.Add(this.panel2);
            this.mainPanel.Controls.Add(this.panel1);
            this.mainPanel.Location = new System.Drawing.Point(-2, 1);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(868, 470);
            this.mainPanel.TabIndex = 0;
            this.mainPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.mainPanel_Paint_1);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(347, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "Main Page";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnVM
            // 
            this.btnVM.AutoSize = true;
            this.btnVM.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVM.Location = new System.Drawing.Point(476, 372);
            this.btnVM.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnVM.Name = "btnVM";
            this.btnVM.Size = new System.Drawing.Size(343, 65);
            this.btnVM.TabIndex = 12;
            this.btnVM.Text = "FIFO/LRU";
            this.btnVM.UseVisualStyleBackColor = true;
            this.btnVM.Click += new System.EventHandler(this.btnVM_Click);
            // 
            // btnMMBF
            // 
            this.btnMMBF.AutoSize = true;
            this.btnMMBF.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMMBF.Location = new System.Drawing.Point(67, 372);
            this.btnMMBF.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnMMBF.Name = "btnMMBF";
            this.btnMMBF.Size = new System.Drawing.Size(328, 65);
            this.btnMMBF.TabIndex = 11;
            this.btnMMBF.Text = "Best Fit";
            this.btnMMBF.UseVisualStyleBackColor = true;
            this.btnMMBF.Click += new System.EventHandler(this.btnMMBF_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(531, 286);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(248, 74);
            this.label5.TabIndex = 10;
            this.label5.Text = "Vitural Memory\r\nFirst In First Out\r\n";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(99, 286);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(274, 74);
            this.label4.TabIndex = 9;
            this.label4.Text = "Main Memory\r\nBest Fit Allocation";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(469, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(363, 74);
            this.label3.TabIndex = 8;
            this.label3.Text = "CPU Scheduling\r\nNon-Preemptive Priority ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(61, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(336, 74);
            this.label2.TabIndex = 7;
            this.label2.Text = "CPU Scheduling\r\nFirst Come First Serve";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNPP
            // 
            this.btnNPP.AutoSize = true;
            this.btnNPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNPP.Location = new System.Drawing.Point(476, 159);
            this.btnNPP.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnNPP.Name = "btnNPP";
            this.btnNPP.Size = new System.Drawing.Size(343, 65);
            this.btnNPP.TabIndex = 4;
            this.btnNPP.Text = "NPP";
            this.btnNPP.UseVisualStyleBackColor = true;
            this.btnNPP.Click += new System.EventHandler(this.btnNPP_Click);
            // 
            // btnFCFS
            // 
            this.btnFCFS.AutoSize = true;
            this.btnFCFS.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFCFS.Location = new System.Drawing.Point(67, 159);
            this.btnFCFS.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnFCFS.Name = "btnFCFS";
            this.btnFCFS.Size = new System.Drawing.Size(328, 65);
            this.btnFCFS.TabIndex = 3;
            this.btnFCFS.Text = "FCFS";
            this.btnFCFS.UseVisualStyleBackColor = true;
            this.btnFCFS.Click += new System.EventHandler(this.btnFCFS_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Location = new System.Drawing.Point(24, 242);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(810, 14);
            this.panel2.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Location = new System.Drawing.Point(421, 64);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(15, 397);
            this.panel1.TabIndex = 1;
            // 
            // panelCPUFCFS
            // 
            this.panelCPUFCFS.Controls.Add(this.FCFSgantt);
            this.panelCPUFCFS.Controls.Add(this.dgvCYFCFS);
            this.panelCPUFCFS.Controls.Add(this.btnCYreturn);
            this.panelCPUFCFS.Controls.Add(this.lblCYCPUU);
            this.panelCPUFCFS.Controls.Add(this.lblCYRT);
            this.panelCPUFCFS.Controls.Add(this.lblCYWT);
            this.panelCPUFCFS.Controls.Add(this.lblCYTAT);
            this.panelCPUFCFS.Controls.Add(this.btnCYStart);
            this.panelCPUFCFS.Controls.Add(this.btnCYClr);
            this.panelCPUFCFS.Controls.Add(this.btnCYRemove);
            this.panelCPUFCFS.Controls.Add(this.btnCYAdd);
            this.panelCPUFCFS.Controls.Add(this.txtCYAT);
            this.panelCPUFCFS.Controls.Add(this.label9);
            this.panelCPUFCFS.Controls.Add(this.txtCYBT);
            this.panelCPUFCFS.Controls.Add(this.label8);
            this.panelCPUFCFS.Controls.Add(this.txtCYPP);
            this.panelCPUFCFS.Controls.Add(this.label7);
            this.panelCPUFCFS.Controls.Add(this.label6);
            this.panelCPUFCFS.Location = new System.Drawing.Point(-2, 0);
            this.panelCPUFCFS.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelCPUFCFS.Name = "panelCPUFCFS";
            this.panelCPUFCFS.Size = new System.Drawing.Size(868, 469);
            this.panelCPUFCFS.TabIndex = 1;
            // 
            // FCFSgantt
            // 
            chartArea17.Name = "ChartArea1";
            this.FCFSgantt.ChartAreas.Add(chartArea17);
            this.FCFSgantt.Location = new System.Drawing.Point(263, 302);
            this.FCFSgantt.Name = "FCFSgantt";
            this.FCFSgantt.Size = new System.Drawing.Size(556, 135);
            this.FCFSgantt.TabIndex = 17;
            this.FCFSgantt.Text = "chart1";
            // 
            // dgvCYFCFS
            // 
            this.dgvCYFCFS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCYFCFS.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCYFCFS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvCYFCFS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCYFCFS.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvCYFCFS.Location = new System.Drawing.Point(263, 52);
            this.dgvCYFCFS.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.dgvCYFCFS.Name = "dgvCYFCFS";
            this.dgvCYFCFS.ReadOnly = true;
            this.dgvCYFCFS.RowTemplate.Height = 24;
            this.dgvCYFCFS.Size = new System.Drawing.Size(556, 233);
            this.dgvCYFCFS.TabIndex = 16;
            this.dgvCYFCFS.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCYFCFS_CellContentClick);
            // 
            // btnCYreturn
            // 
            this.btnCYreturn.AutoSize = true;
            this.btnCYreturn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCYreturn.Location = new System.Drawing.Point(20, 426);
            this.btnCYreturn.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnCYreturn.Name = "btnCYreturn";
            this.btnCYreturn.Size = new System.Drawing.Size(214, 42);
            this.btnCYreturn.TabIndex = 15;
            this.btnCYreturn.Text = "Return to Main Page";
            this.btnCYreturn.UseVisualStyleBackColor = true;
            this.btnCYreturn.Click += new System.EventHandler(this.btnCYreturn_Click);
            // 
            // lblCYCPUU
            // 
            this.lblCYCPUU.AutoSize = true;
            this.lblCYCPUU.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCYCPUU.Location = new System.Drawing.Point(20, 400);
            this.lblCYCPUU.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCYCPUU.Name = "lblCYCPUU";
            this.lblCYCPUU.Size = new System.Drawing.Size(141, 24);
            this.lblCYCPUU.TabIndex = 14;
            this.lblCYCPUU.Text = "CPU Utilization :";
            // 
            // lblCYRT
            // 
            this.lblCYRT.AutoSize = true;
            this.lblCYRT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCYRT.Location = new System.Drawing.Point(20, 374);
            this.lblCYRT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCYRT.Name = "lblCYRT";
            this.lblCYRT.Size = new System.Drawing.Size(154, 24);
            this.lblCYRT.TabIndex = 13;
            this.lblCYRT.Text = "Response Time :";
            this.lblCYRT.Click += new System.EventHandler(this.lblCYRT_Click);
            // 
            // lblCYWT
            // 
            this.lblCYWT.AutoSize = true;
            this.lblCYWT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCYWT.Location = new System.Drawing.Point(20, 327);
            this.lblCYWT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCYWT.Name = "lblCYWT";
            this.lblCYWT.Size = new System.Drawing.Size(130, 48);
            this.lblCYWT.TabIndex = 12;
            this.lblCYWT.Text = "Average\r\nWaiting Time :";
            // 
            // lblCYTAT
            // 
            this.lblCYTAT.AutoSize = true;
            this.lblCYTAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCYTAT.Location = new System.Drawing.Point(20, 281);
            this.lblCYTAT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCYTAT.Name = "lblCYTAT";
            this.lblCYTAT.Size = new System.Drawing.Size(131, 48);
            this.lblCYTAT.TabIndex = 11;
            this.lblCYTAT.Text = "Average Turn \r\nAround Time :";
            // 
            // btnCYStart
            // 
            this.btnCYStart.AutoSize = true;
            this.btnCYStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCYStart.Location = new System.Drawing.Point(20, 233);
            this.btnCYStart.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnCYStart.Name = "btnCYStart";
            this.btnCYStart.Size = new System.Drawing.Size(213, 42);
            this.btnCYStart.TabIndex = 10;
            this.btnCYStart.Text = "Start Executing";
            this.btnCYStart.UseVisualStyleBackColor = true;
            this.btnCYStart.Click += new System.EventHandler(this.btnCYStart_Click);
            // 
            // btnCYClr
            // 
            this.btnCYClr.AutoSize = true;
            this.btnCYClr.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCYClr.Location = new System.Drawing.Point(21, 188);
            this.btnCYClr.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnCYClr.Name = "btnCYClr";
            this.btnCYClr.Size = new System.Drawing.Size(213, 42);
            this.btnCYClr.TabIndex = 9;
            this.btnCYClr.Text = "Clear Table";
            this.btnCYClr.UseVisualStyleBackColor = true;
            this.btnCYClr.Click += new System.EventHandler(this.btnCYClr_Click);
            // 
            // btnCYRemove
            // 
            this.btnCYRemove.AutoSize = true;
            this.btnCYRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCYRemove.Location = new System.Drawing.Point(20, 143);
            this.btnCYRemove.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnCYRemove.Name = "btnCYRemove";
            this.btnCYRemove.Size = new System.Drawing.Size(113, 42);
            this.btnCYRemove.TabIndex = 8;
            this.btnCYRemove.Text = "Remove\r\n";
            this.btnCYRemove.UseVisualStyleBackColor = true;
            this.btnCYRemove.Click += new System.EventHandler(this.btnCYRemove_Click);
            // 
            // btnCYAdd
            // 
            this.btnCYAdd.AutoSize = true;
            this.btnCYAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCYAdd.Location = new System.Drawing.Point(137, 143);
            this.btnCYAdd.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnCYAdd.Name = "btnCYAdd";
            this.btnCYAdd.Size = new System.Drawing.Size(96, 42);
            this.btnCYAdd.TabIndex = 7;
            this.btnCYAdd.Text = "Add";
            this.btnCYAdd.UseVisualStyleBackColor = true;
            this.btnCYAdd.Click += new System.EventHandler(this.btnCYAdd_Click);
            // 
            // txtCYAT
            // 
            this.txtCYAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCYAT.Location = new System.Drawing.Point(151, 80);
            this.txtCYAT.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.txtCYAT.Name = "txtCYAT";
            this.txtCYAT.Size = new System.Drawing.Size(83, 28);
            this.txtCYAT.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(31, 81);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 24);
            this.label9.TabIndex = 5;
            this.label9.Text = "Arrival Time :";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtCYBT
            // 
            this.txtCYBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCYBT.Location = new System.Drawing.Point(151, 110);
            this.txtCYBT.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.txtCYBT.Name = "txtCYBT";
            this.txtCYBT.Size = new System.Drawing.Size(83, 28);
            this.txtCYBT.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(41, 110);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 24);
            this.label8.TabIndex = 3;
            this.label8.Text = "Burst Time :";
            // 
            // txtCYPP
            // 
            this.txtCYPP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCYPP.Location = new System.Drawing.Point(151, 52);
            this.txtCYPP.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.txtCYPP.Name = "txtCYPP";
            this.txtCYPP.Size = new System.Drawing.Size(83, 28);
            this.txtCYPP.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 54);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 24);
            this.label7.TabIndex = 1;
            this.label7.Text = "Process Num :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(258, 13);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(410, 26);
            this.label6.TabIndex = 0;
            this.label6.Text = "CPU Scheduling - First Come First Serve";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelNPP
            // 
            this.panelNPP.Controls.Add(this.chtPriority);
            this.panelNPP.Controls.Add(this.lblResult2);
            this.panelNPP.Controls.Add(this.txtSave);
            this.panelNPP.Controls.Add(this.btnLocation);
            this.panelNPP.Controls.Add(this.btnSave);
            this.panelNPP.Controls.Add(this.label10);
            this.panelNPP.Controls.Add(this.progressBar1);
            this.panelNPP.Controls.Add(this.dataGridView1);
            this.panelNPP.Controls.Add(this.label11);
            this.panelNPP.Controls.Add(this.btnBack);
            this.panelNPP.Controls.Add(this.lblResult);
            this.panelNPP.Controls.Add(this.btnStart);
            this.panelNPP.Controls.Add(this.btnClear);
            this.panelNPP.Controls.Add(this.btnAdd);
            this.panelNPP.Controls.Add(this.btnRemove);
            this.panelNPP.Controls.Add(this.txtPriority);
            this.panelNPP.Controls.Add(this.label12);
            this.panelNPP.Controls.Add(this.txtArrivalTime);
            this.panelNPP.Controls.Add(this.txtBurstTime);
            this.panelNPP.Controls.Add(this.txtProcess);
            this.panelNPP.Controls.Add(this.label13);
            this.panelNPP.Controls.Add(this.label14);
            this.panelNPP.Controls.Add(this.label15);
            this.panelNPP.Location = new System.Drawing.Point(-2, 0);
            this.panelNPP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panelNPP.Name = "panelNPP";
            this.panelNPP.Size = new System.Drawing.Size(868, 471);
            this.panelNPP.TabIndex = 2;
            this.panelNPP.Paint += new System.Windows.Forms.PaintEventHandler(this.panelNPP_Paint);
            // 
            // chtPriority
            // 
            chartArea18.Name = "ChartArea1";
            this.chtPriority.ChartAreas.Add(chartArea18);
            this.chtPriority.Location = new System.Drawing.Point(283, 250);
            this.chtPriority.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.chtPriority.Name = "chtPriority";
            this.chtPriority.Size = new System.Drawing.Size(541, 114);
            this.chtPriority.TabIndex = 66;
            this.chtPriority.Text = "chart1";
            // 
            // lblResult2
            // 
            this.lblResult2.AutoSize = true;
            this.lblResult2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult2.Location = new System.Drawing.Point(27, 354);
            this.lblResult2.Name = "lblResult2";
            this.lblResult2.Size = new System.Drawing.Size(45, 20);
            this.lblResult2.TabIndex = 65;
            this.lblResult2.Text = "Hello";
            // 
            // txtSave
            // 
            this.txtSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSave.Location = new System.Drawing.Point(386, 406);
            this.txtSave.Name = "txtSave";
            this.txtSave.Size = new System.Drawing.Size(255, 27);
            this.txtSave.TabIndex = 64;
            // 
            // btnLocation
            // 
            this.btnLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocation.Location = new System.Drawing.Point(645, 401);
            this.btnLocation.Name = "btnLocation";
            this.btnLocation.Size = new System.Drawing.Size(112, 34);
            this.btnLocation.TabIndex = 63;
            this.btnLocation.Text = "File Location";
            this.btnLocation.UseVisualStyleBackColor = true;
            this.btnLocation.Click += new System.EventHandler(this.btnLocation_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(763, 400);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(71, 34);
            this.btnSave.TabIndex = 62;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(271, 406);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 22);
            this.label10.TabIndex = 61;
            this.label10.Text = "File Location:";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(275, 242);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(559, 133);
            this.progressBar1.TabIndex = 60;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Process,
            this.ArrivalTime,
            this.BurstTime,
            this.Priority});
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle40;
            this.dataGridView1.Location = new System.Drawing.Point(275, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridView1.RowHeadersWidth = 54;
            this.dataGridView1.Size = new System.Drawing.Size(559, 178);
            this.dataGridView1.TabIndex = 59;
            // 
            // Process
            // 
            this.Process.HeaderText = "Process";
            this.Process.Name = "Process";
            this.Process.ReadOnly = true;
            this.Process.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Process.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Process.Width = 107;
            // 
            // ArrivalTime
            // 
            this.ArrivalTime.HeaderText = "Arrival Time";
            this.ArrivalTime.Name = "ArrivalTime";
            this.ArrivalTime.ReadOnly = true;
            this.ArrivalTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ArrivalTime.Width = 148;
            // 
            // BurstTime
            // 
            this.BurstTime.HeaderText = "Burst Time";
            this.BurstTime.Name = "BurstTime";
            this.BurstTime.ReadOnly = true;
            this.BurstTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BurstTime.Width = 136;
            // 
            // Priority
            // 
            this.Priority.HeaderText = "Priority";
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Priority.Width = 94;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(270, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(424, 26);
            this.label11.TabIndex = 58;
            this.label11.Text = "CPU Scheduling - Non-Preemptive Priority";
            // 
            // btnBack
            // 
            this.btnBack.AutoSize = true;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(31, 400);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(207, 42);
            this.btnBack.TabIndex = 57;
            this.btnBack.Text = "Back to Main Page";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(27, 329);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(45, 20);
            this.lblResult.TabIndex = 56;
            this.lblResult.Text = "Hello";
            this.lblResult.Click += new System.EventHandler(this.lblResult_Click);
            // 
            // btnStart
            // 
            this.btnStart.AutoSize = true;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(28, 274);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(210, 41);
            this.btnStart.TabIndex = 55;
            this.btnStart.Text = "Start Executing";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnClear
            // 
            this.btnClear.AutoSize = true;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(28, 227);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(210, 42);
            this.btnClear.TabIndex = 54;
            this.btnClear.Text = "Clear Table";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSize = true;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(162, 179);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(76, 42);
            this.btnAdd.TabIndex = 53;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.AutoSize = true;
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(28, 179);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(134, 42);
            this.btnRemove.TabIndex = 52;
            this.btnRemove.Text = "Remove Row";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // txtPriority
            // 
            this.txtPriority.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriority.Location = new System.Drawing.Point(137, 143);
            this.txtPriority.Name = "txtPriority";
            this.txtPriority.Size = new System.Drawing.Size(100, 29);
            this.txtPriority.TabIndex = 51;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(26, 144);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 24);
            this.label12.TabIndex = 50;
            this.label12.Text = "Priority";
            // 
            // txtArrivalTime
            // 
            this.txtArrivalTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrivalTime.Location = new System.Drawing.Point(137, 84);
            this.txtArrivalTime.Name = "txtArrivalTime";
            this.txtArrivalTime.Size = new System.Drawing.Size(100, 29);
            this.txtArrivalTime.TabIndex = 49;
            // 
            // txtBurstTime
            // 
            this.txtBurstTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBurstTime.Location = new System.Drawing.Point(137, 113);
            this.txtBurstTime.Name = "txtBurstTime";
            this.txtBurstTime.Size = new System.Drawing.Size(100, 29);
            this.txtBurstTime.TabIndex = 48;
            // 
            // txtProcess
            // 
            this.txtProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProcess.Location = new System.Drawing.Point(137, 53);
            this.txtProcess.Name = "txtProcess";
            this.txtProcess.Size = new System.Drawing.Size(100, 29);
            this.txtProcess.TabIndex = 47;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(25, 83);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 24);
            this.label13.TabIndex = 46;
            this.label13.Text = "Arrival Time";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(24, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 24);
            this.label14.TabIndex = 45;
            this.label14.Text = "Burst Time";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(24, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 24);
            this.label15.TabIndex = 44;
            this.label15.Text = "Process P";
            // 
            // panelMainMemory
            // 
            this.panelMainMemory.Controls.Add(this.MMMBlockchart);
            this.panelMainMemory.Controls.Add(this.panel4);
            this.panelMainMemory.Controls.Add(this.returnMP);
            this.panelMainMemory.Controls.Add(this.label16);
            this.panelMainMemory.Controls.Add(this.errorJY);
            this.panelMainMemory.Controls.Add(this.GridViewMemJY2);
            this.panelMainMemory.Controls.Add(this.processQueueJY1);
            this.panelMainMemory.Controls.Add(this.unloadedBlk);
            this.panelMainMemory.Controls.Add(this.extFrag);
            this.panelMainMemory.Controls.Add(this.internFrag);
            this.panelMainMemory.Controls.Add(this.startMM);
            this.panelMainMemory.Controls.Add(this.processSizeTxtBox);
            this.panelMainMemory.Controls.Add(this.orderNoTxtBox);
            this.panelMainMemory.Controls.Add(this.label18);
            this.panelMainMemory.Controls.Add(this.label19);
            this.panelMainMemory.Controls.Add(this.addProcess);
            this.panelMainMemory.Controls.Add(this.addMemBlock);
            this.panelMainMemory.Controls.Add(this.newMemBlk);
            this.panelMainMemory.Controls.Add(this.label20);
            this.panelMainMemory.Controls.Add(this.label21);
            this.panelMainMemory.Controls.Add(this.label22);
            this.panelMainMemory.Controls.Add(this.label23);
            this.panelMainMemory.Controls.Add(this.removeblk);
            this.panelMainMemory.Controls.Add(this.label24);
            this.panelMainMemory.Controls.Add(this.label25);
            this.panelMainMemory.Controls.Add(this.MMDChart);
            this.panelMainMemory.Controls.Add(this.processQueueJY2);
            this.panelMainMemory.Controls.Add(this.label26);
            this.panelMainMemory.Location = new System.Drawing.Point(-2, 0);
            this.panelMainMemory.Name = "panelMainMemory";
            this.panelMainMemory.Size = new System.Drawing.Size(868, 471);
            this.panelMainMemory.TabIndex = 3;
            this.panelMainMemory.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // MMMBlockchart
            // 
            chartArea19.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea19.Name = "ChartArea1";
            this.MMMBlockchart.ChartAreas.Add(chartArea19);
            this.MMMBlockchart.Location = new System.Drawing.Point(19, 91);
            this.MMMBlockchart.Name = "MMMBlockchart";
            this.MMMBlockchart.Size = new System.Drawing.Size(158, 279);
            this.MMMBlockchart.TabIndex = 61;
            this.MMMBlockchart.Text = "chart1";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Location = new System.Drawing.Point(386, 91);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(471, 10);
            this.panel4.TabIndex = 60;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // returnMP
            // 
            this.returnMP.AutoSize = true;
            this.returnMP.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnMP.Location = new System.Drawing.Point(6, 400);
            this.returnMP.Name = "returnMP";
            this.returnMP.Size = new System.Drawing.Size(176, 34);
            this.returnMP.TabIndex = 58;
            this.returnMP.Text = "Back to Main Page";
            this.returnMP.UseVisualStyleBackColor = true;
            this.returnMP.Click += new System.EventHandler(this.returnMP_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(261, 58);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 13);
            this.label16.TabIndex = 57;
            // 
            // errorJY
            // 
            this.errorJY.AutoSize = true;
            this.errorJY.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorJY.ForeColor = System.Drawing.Color.Red;
            this.errorJY.Location = new System.Drawing.Point(625, 116);
            this.errorJY.Name = "errorJY";
            this.errorJY.Size = new System.Drawing.Size(227, 24);
            this.errorJY.TabIndex = 56;
            this.errorJY.Text = "*Order No is already used";
            this.errorJY.Visible = false;
            // 
            // GridViewMemJY2
            // 
            this.GridViewMemJY2.AllowUserToAddRows = false;
            this.GridViewMemJY2.AllowUserToDeleteRows = false;
            this.GridViewMemJY2.AllowUserToResizeColumns = false;
            this.GridViewMemJY2.AllowUserToResizeRows = false;
            this.GridViewMemJY2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewMemJY2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewMemJY2.ColumnHeadersVisible = false;
            this.GridViewMemJY2.Location = new System.Drawing.Point(21, 94);
            this.GridViewMemJY2.Name = "GridViewMemJY2";
            this.GridViewMemJY2.ReadOnly = true;
            this.GridViewMemJY2.RowHeadersVisible = false;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.GridViewMemJY2.RowsDefaultCellStyle = dataGridViewCellStyle42;
            this.GridViewMemJY2.Size = new System.Drawing.Size(156, 273);
            this.GridViewMemJY2.TabIndex = 54;
            // 
            // processQueueJY1
            // 
            this.processQueueJY1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.processQueueJY1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.processQueueJY1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.processQueueJY1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.processQueueJY1.DefaultCellStyle = dataGridViewCellStyle44;
            this.processQueueJY1.Location = new System.Drawing.Point(386, 187);
            this.processQueueJY1.Name = "processQueueJY1";
            this.processQueueJY1.Size = new System.Drawing.Size(415, 159);
            this.processQueueJY1.TabIndex = 53;
            // 
            // unloadedBlk
            // 
            this.unloadedBlk.AutoSize = true;
            this.unloadedBlk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unloadedBlk.Location = new System.Drawing.Point(569, 404);
            this.unloadedBlk.Name = "unloadedBlk";
            this.unloadedBlk.Size = new System.Drawing.Size(158, 24);
            this.unloadedBlk.TabIndex = 52;
            this.unloadedBlk.Text = "unloadedProcess";
            this.unloadedBlk.Visible = false;
            this.unloadedBlk.Click += new System.EventHandler(this.unloadedBlk_Click);
            // 
            // extFrag
            // 
            this.extFrag.AutoSize = true;
            this.extFrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extFrag.Location = new System.Drawing.Point(467, 380);
            this.extFrag.Name = "extFrag";
            this.extFrag.Size = new System.Drawing.Size(112, 24);
            this.extFrag.TabIndex = 51;
            this.extFrag.Text = "externValue";
            this.extFrag.Visible = false;
            this.extFrag.Click += new System.EventHandler(this.extFrag_Click);
            // 
            // internFrag
            // 
            this.internFrag.AutoSize = true;
            this.internFrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.internFrag.Location = new System.Drawing.Point(467, 354);
            this.internFrag.Name = "internFrag";
            this.internFrag.Size = new System.Drawing.Size(106, 24);
            this.internFrag.TabIndex = 50;
            this.internFrag.Text = "internValue";
            this.internFrag.Visible = false;
            this.internFrag.Click += new System.EventHandler(this.internFrag_Click);
            // 
            // startMM
            // 
            this.startMM.AutoSize = true;
            this.startMM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startMM.Location = new System.Drawing.Point(689, 354);
            this.startMM.Name = "startMM";
            this.startMM.Size = new System.Drawing.Size(113, 34);
            this.startMM.TabIndex = 48;
            this.startMM.Text = "Start";
            this.startMM.UseVisualStyleBackColor = true;
            this.startMM.Click += new System.EventHandler(this.startMM_Click);
            // 
            // processSizeTxtBox
            // 
            this.processSizeTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.processSizeTxtBox.Location = new System.Drawing.Point(521, 147);
            this.processSizeTxtBox.Name = "processSizeTxtBox";
            this.processSizeTxtBox.Size = new System.Drawing.Size(100, 29);
            this.processSizeTxtBox.TabIndex = 47;
            // 
            // orderNoTxtBox
            // 
            this.orderNoTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderNoTxtBox.Location = new System.Drawing.Point(521, 114);
            this.orderNoTxtBox.Name = "orderNoTxtBox";
            this.orderNoTxtBox.Size = new System.Drawing.Size(100, 29);
            this.orderNoTxtBox.TabIndex = 46;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(382, 150);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(124, 24);
            this.label18.TabIndex = 45;
            this.label18.Text = "Process Size:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(382, 114);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 24);
            this.label19.TabIndex = 44;
            this.label19.Text = "Order No:";
            // 
            // addProcess
            // 
            this.addProcess.AutoSize = true;
            this.addProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProcess.Location = new System.Drawing.Point(725, 145);
            this.addProcess.Name = "addProcess";
            this.addProcess.Size = new System.Drawing.Size(76, 34);
            this.addProcess.TabIndex = 43;
            this.addProcess.Text = "Add";
            this.addProcess.UseVisualStyleBackColor = true;
            this.addProcess.Click += new System.EventHandler(this.addProcess_Click);
            // 
            // addMemBlock
            // 
            this.addMemBlock.AutoSize = true;
            this.addMemBlock.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addMemBlock.Location = new System.Drawing.Point(726, 55);
            this.addMemBlock.Name = "addMemBlock";
            this.addMemBlock.Size = new System.Drawing.Size(76, 34);
            this.addMemBlock.TabIndex = 42;
            this.addMemBlock.Text = "Add";
            this.addMemBlock.UseVisualStyleBackColor = true;
            this.addMemBlock.Click += new System.EventHandler(this.addMemBlock_Click);
            // 
            // newMemBlk
            // 
            this.newMemBlk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newMemBlk.Location = new System.Drawing.Point(612, 56);
            this.newMemBlk.Name = "newMemBlk";
            this.newMemBlk.Size = new System.Drawing.Size(100, 29);
            this.newMemBlk.TabIndex = 41;
            this.newMemBlk.TextChanged += new System.EventHandler(this.newMemBlk_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(382, 58);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(224, 24);
            this.label20.TabIndex = 40;
            this.label20.Text = "Add New Memory Block :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(382, 405);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(177, 24);
            this.label21.TabIndex = 39;
            this.label21.Text = "Process not loaded:";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(382, 380);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 24);
            this.label22.TabIndex = 38;
            this.label22.Text = "External:";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(382, 354);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 24);
            this.label23.TabIndex = 37;
            this.label23.Text = "Internal:";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // removeblk
            // 
            this.removeblk.AutoSize = true;
            this.removeblk.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeblk.Location = new System.Drawing.Point(230, 399);
            this.removeblk.Name = "removeblk";
            this.removeblk.Size = new System.Drawing.Size(90, 34);
            this.removeblk.TabIndex = 36;
            this.removeblk.Text = "Clear All";
            this.removeblk.UseVisualStyleBackColor = true;
            this.removeblk.Click += new System.EventHandler(this.removeblk_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(225, 58);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(92, 25);
            this.label24.TabIndex = 35;
            this.label24.Text = "Diagram";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(25, 60);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(148, 25);
            this.label25.TabIndex = 34;
            this.label25.Text = "Memory Block";
            // 
            // MMDChart
            // 
            chartArea20.Name = "ChartArea1";
            this.MMDChart.ChartAreas.Add(chartArea20);
            this.MMDChart.Location = new System.Drawing.Point(198, 92);
            this.MMDChart.Name = "MMDChart";
            this.MMDChart.Size = new System.Drawing.Size(158, 279);
            this.MMDChart.TabIndex = 62;
            this.MMDChart.Text = "chart2";
            // 
            // processQueueJY2
            // 
            this.processQueueJY2.AllowUserToAddRows = false;
            this.processQueueJY2.AllowUserToDeleteRows = false;
            this.processQueueJY2.AllowUserToResizeColumns = false;
            this.processQueueJY2.AllowUserToResizeRows = false;
            this.processQueueJY2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.processQueueJY2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.processQueueJY2.ColumnHeadersVisible = false;
            this.processQueueJY2.Location = new System.Drawing.Point(203, 94);
            this.processQueueJY2.Name = "processQueueJY2";
            this.processQueueJY2.ReadOnly = true;
            this.processQueueJY2.RowHeadersVisible = false;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.processQueueJY2.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.processQueueJY2.Size = new System.Drawing.Size(146, 273);
            this.processQueueJY2.TabIndex = 55;
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(11, 10);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(847, 37);
            this.label26.TabIndex = 59;
            this.label26.Text = "Main Memory Management - Best Fit";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panelVM
            // 
            this.panelVM.Controls.Add(this.label17);
            this.panelVM.Controls.Add(this.lblPageFault);
            this.panelVM.Controls.Add(this.label27);
            this.panelVM.Controls.Add(this.lblProbability);
            this.panelVM.Controls.Add(this.csdataGridView1);
            this.panelVM.Controls.Add(this.button1);
            this.panelVM.Controls.Add(this.button2);
            this.panelVM.Controls.Add(this.btnFIFO);
            this.panelVM.Controls.Add(this.label28);
            this.panelVM.Controls.Add(this.btnSubmit);
            this.panelVM.Controls.Add(this.txtDatabits);
            this.panelVM.Controls.Add(this.label29);
            this.panelVM.Controls.Add(this.txtFrame);
            this.panelVM.Controls.Add(this.label30);
            this.panelVM.Controls.Add(this.btnBackVM);
            this.panelVM.Location = new System.Drawing.Point(1, 0);
            this.panelVM.Name = "panelVM";
            this.panelVM.Size = new System.Drawing.Size(865, 471);
            this.panelVM.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(24, 256);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 8;
            this.label17.Text = "Page Fault: ";
            // 
            // lblPageFault
            // 
            this.lblPageFault.AutoSize = true;
            this.lblPageFault.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageFault.Location = new System.Drawing.Point(122, 256);
            this.lblPageFault.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPageFault.Name = "lblPageFault";
            this.lblPageFault.Size = new System.Drawing.Size(0, 20);
            this.lblPageFault.TabIndex = 9;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(22, 285);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(188, 20);
            this.label27.TabIndex = 7;
            this.label27.Text = "Probability of Occurence: ";
            // 
            // lblProbability
            // 
            this.lblProbability.AutoSize = true;
            this.lblProbability.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProbability.Location = new System.Drawing.Point(218, 285);
            this.lblProbability.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProbability.Name = "lblProbability";
            this.lblProbability.Size = new System.Drawing.Size(0, 20);
            this.lblProbability.TabIndex = 10;
            // 
            // csdataGridView1
            // 
            this.csdataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.csdataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Frame,
            this.databits,
            this.PageFault,
            this.Occurence,
            this.METHOD});
            this.csdataGridView1.Location = new System.Drawing.Point(328, 94);
            this.csdataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.csdataGridView1.Name = "csdataGridView1";
            this.csdataGridView1.RowTemplate.Height = 24;
            this.csdataGridView1.Size = new System.Drawing.Size(515, 191);
            this.csdataGridView1.TabIndex = 0;
            // 
            // Frame
            // 
            this.Frame.HeaderText = "Frame";
            this.Frame.Name = "Frame";
            this.Frame.Width = 70;
            // 
            // databits
            // 
            this.databits.HeaderText = "Data Bits";
            this.databits.Name = "databits";
            // 
            // PageFault
            // 
            this.PageFault.HeaderText = "Page Fault";
            this.PageFault.Name = "PageFault";
            this.PageFault.Width = 120;
            // 
            // Occurence
            // 
            this.Occurence.HeaderText = "Occurence";
            this.Occurence.Name = "Occurence";
            // 
            // METHOD
            // 
            this.METHOD.HeaderText = "Method";
            this.METHOD.Name = "METHOD";
            this.METHOD.Width = 70;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(328, 302);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 36);
            this.button1.TabIndex = 6;
            this.button1.Text = "Remove Row";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(708, 302);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 36);
            this.button2.TabIndex = 4;
            this.button2.Text = "Clear Table";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnFIFO
            // 
            this.btnFIFO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFIFO.Location = new System.Drawing.Point(25, 187);
            this.btnFIFO.Margin = new System.Windows.Forms.Padding(2);
            this.btnFIFO.Name = "btnFIFO";
            this.btnFIFO.Size = new System.Drawing.Size(131, 37);
            this.btnFIFO.TabIndex = 7;
            this.btnFIFO.Text = "Start FIFO";
            this.btnFIFO.UseVisualStyleBackColor = true;
            this.btnFIFO.Click += new System.EventHandler(this.btnFIFO_Click_1);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(20, 133);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(90, 24);
            this.label28.TabIndex = 1;
            this.label28.Text = "Data bits :";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(168, 187);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(131, 37);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "Start LRU";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click_1);
            // 
            // txtDatabits
            // 
            this.txtDatabits.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDatabits.Location = new System.Drawing.Point(119, 133);
            this.txtDatabits.Margin = new System.Windows.Forms.Padding(2);
            this.txtDatabits.Name = "txtDatabits";
            this.txtDatabits.Size = new System.Drawing.Size(179, 29);
            this.txtDatabits.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(23, 94);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(75, 24);
            this.label29.TabIndex = 0;
            this.label29.Text = "Frame :";
            // 
            // txtFrame
            // 
            this.txtFrame.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrame.Location = new System.Drawing.Point(123, 92);
            this.txtFrame.Margin = new System.Windows.Forms.Padding(2);
            this.txtFrame.Name = "txtFrame";
            this.txtFrame.Size = new System.Drawing.Size(149, 29);
            this.txtFrame.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(23, 29);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(467, 28);
            this.label30.TabIndex = 22;
            this.label30.Text = "Virtual Memory Management - FIFO and LRU";
            // 
            // btnBackVM
            // 
            this.btnBackVM.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackVM.Location = new System.Drawing.Point(27, 344);
            this.btnBackVM.Name = "btnBackVM";
            this.btnBackVM.Size = new System.Drawing.Size(194, 34);
            this.btnBackVM.TabIndex = 21;
            this.btnBackVM.Text = "Back to Main Menu";
            this.btnBackVM.UseVisualStyleBackColor = true;
            this.btnBackVM.Click += new System.EventHandler(this.btnBackVM_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 472);
            this.Controls.Add(this.panelCPUFCFS);
            this.Controls.Add(this.panelMainMemory);
            this.Controls.Add(this.panelVM);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.panelNPP);
            this.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.Name = "Form1";
            this.Text = "CAOS Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.panelCPUFCFS.ResumeLayout(false);
            this.panelCPUFCFS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FCFSgantt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCYFCFS)).EndInit();
            this.panelNPP.ResumeLayout(false);
            this.panelNPP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chtPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelMainMemory.ResumeLayout(false);
            this.panelMainMemory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MMMBlockchart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewMemJY2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.processQueueJY1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MMDChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.processQueueJY2)).EndInit();
            this.panelVM.ResumeLayout(false);
            this.panelVM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.csdataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Button btnVM;
        private System.Windows.Forms.Button btnMMBF;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnNPP;
        private System.Windows.Forms.Button btnFCFS;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelCPUFCFS;
        private System.Windows.Forms.Label lblCYCPUU;
        private System.Windows.Forms.Label lblCYRT;
        private System.Windows.Forms.Label lblCYWT;
        private System.Windows.Forms.Label lblCYTAT;
        private System.Windows.Forms.Button btnCYStart;
        private System.Windows.Forms.Button btnCYClr;
        private System.Windows.Forms.Button btnCYRemove;
        private System.Windows.Forms.Button btnCYAdd;
        private System.Windows.Forms.TextBox txtCYAT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCYBT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCYPP;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCYreturn;
        private System.Windows.Forms.DataGridView dgvCYFCFS;
        private System.Windows.Forms.DataVisualization.Charting.Chart FCFSgantt;
        private System.Windows.Forms.Panel panelNPP;
        private System.Windows.Forms.DataVisualization.Charting.Chart chtPriority;
        private System.Windows.Forms.Label lblResult2;
        private System.Windows.Forms.TextBox txtSave;
        private System.Windows.Forms.Button btnLocation;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TextBox txtPriority;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtArrivalTime;
        private System.Windows.Forms.TextBox txtBurstTime;
        private System.Windows.Forms.TextBox txtProcess;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Process;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArrivalTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn BurstTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priority;
        private System.Windows.Forms.Panel panelMainMemory;
        private System.Windows.Forms.Button returnMP;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label errorJY;
        private System.Windows.Forms.DataGridView processQueueJY2;
        private System.Windows.Forms.DataGridView GridViewMemJY2;
        private System.Windows.Forms.DataGridView processQueueJY1;
        private System.Windows.Forms.Label unloadedBlk;
        private System.Windows.Forms.Label extFrag;
        private System.Windows.Forms.Label internFrag;
        private System.Windows.Forms.Button startMM;
        private System.Windows.Forms.TextBox processSizeTxtBox;
        private System.Windows.Forms.TextBox orderNoTxtBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button addProcess;
        private System.Windows.Forms.Button addMemBlock;
        private System.Windows.Forms.TextBox newMemBlk;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button removeblk;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataVisualization.Charting.Chart MMDChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart MMMBlockchart;
        private System.Windows.Forms.Panel panelVM;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblPageFault;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblProbability;
        private System.Windows.Forms.DataGridView csdataGridView1;
        private System.Windows.Forms.Button btnBackVM;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button btnFIFO;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDatabits;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtFrame;
        private System.Windows.Forms.DataGridViewTextBoxColumn Frame;
        private System.Windows.Forms.DataGridViewTextBoxColumn databits;
        private System.Windows.Forms.DataGridViewTextBoxColumn PageFault;
        private System.Windows.Forms.DataGridViewTextBoxColumn Occurence;
        private System.Windows.Forms.DataGridViewTextBoxColumn METHOD;
    }
}

